#!/bin/sh
case "$0" in
    */*) launcher_dir=${0%/*} ;;
    *) launcher_dir=. ;;
esac
launcher_dir=$(CDPATH= cd -P "$launcher_dir" && pwd) || exit 1
for interpreter in python3 python; do
    if command -v "$interpreter" >/dev/null 2>&1 &&
       "$interpreter" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
        exec "$interpreter" -B "$launcher_dir/launch.py" "$@"
    fi
done
printf '%s\n' 'Python 3.10 or newer was not found as python3 or python on PATH.' 'Use an installed Python 3.10+ environment, then run this start file again. Nothing was installed.' >&2
exit 127
