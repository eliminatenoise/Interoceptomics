import {voxelLabel} from './section-coordinates.js';

export function crossedVoxels(start, end) {
  const point = [...start];
  const steps = end.map((value, axis) => value - start[axis]);
  const direction = steps.map(Math.sign);
  const denominators = steps.map(step => 2 * Math.abs(step));
  const numerators = [1, 1, 1];
  const path = [];
  let entry = 0;
  while (true) {
    const remaining = steps.flatMap((_, axis) => point[axis] === end[axis] ? [] : [axis]);
    if (!remaining.length) {
      path.push({indices: point, fraction: path.length ? 1 : 0});
      return path;
    }
    // Half-integer faces give odd integer numerators. Compare the times exactly
    // so a shared edge or corner advances all tied axes without adding side cells.
    const compare = (a, b) => numerators[a] * denominators[b] - numerators[b] * denominators[a];
    const next = remaining.reduce((a, b) => compare(a, b) <= 0 ? a : b);
    const exit = numerators[next] / denominators[next];
    path.push({indices: [...point], fraction: path.length ? (entry + exit) / 2 : 0});
    for (const axis of remaining.filter(axis => compare(axis, next) === 0)) {
      point[axis] += direction[axis];
      numerators[axis] += 2;
    }
    entry = exit;
  }
}

export function bindRulerWalk(details, getView, renderModel) {
  const slider = details.querySelector('input');
  const reading = details.querySelector('[role="status"]');
  const buttons = [...details.querySelectorAll('[data-ruler-step]')];
  let endpoints = [];
  let path;
  let length;
  let selected;
  let request = 0;
  let animation;
  let pending;

  function cursor() {
    const point = getView()?.selected;
    if (point && selected?.every((value, axis) => value === point.indices[axis])) return point;
  }

  function updatePosition() {
    const position = Number(slider.value);
    const text = 'Voxel ' + position + ' of ' + path.length;
    slider.setAttribute('aria-valuetext', text);
    for (const button of buttons) {
      const next = position + Number(button.dataset.rulerStep);
      button.setAttribute('aria-disabled', String(next < 1 || next > path.length));
    }
    return text;
  }

  async function move(attempt) {
    const {mine, view} = attempt;
    const current = () => mine === request && details.open && getView() === view;
    if (!path || !view || !current()) return;
    const position = updatePosition();
    const {indices, fraction} = path[Number(slider.value) - 1];
    const distance = 'Line sample ' + (fraction * length).toFixed(3) + ' mm from A.';
    const prefix = position + '. ' + distance + ' ';
    reading.textContent = prefix + 'Opening section…';
    try {
      const reason = await view.follow(indices, () => {
        if (!current()) return false;
        attempt.committing = true;
        return true;
      });
      if (mine !== request || !details.open || getView()?.reader !== view.reader) return;
      if (reason) {
        if (current()) reading.textContent = prefix + reason + ' The last section stays open.';
        return;
      }
      selected = indices;
      const accepted = cursor();
      if (!accepted) {
        selected = undefined;
        reading.textContent = 'Section moved. Show a ruler voxel to return to the line.';
        return;
      }
      reading.textContent = prefix + 'Voxel centre ' + voxelLabel((axis, value) => value, accepted.values) +
        ' · ' + accepted.label;
      renderModel();
    } catch (error) {
      if (!current()) return;
      reading.textContent = prefix + 'This atlas section couldn’t load. The last section stays open.';
      console.warn('Ruler section unavailable:', error);
    } finally {
      if (pending === attempt) pending = undefined;
    }
  }

  function queue() {
    if (!path || !details.open) return;
    updatePosition();
    selected = undefined;
    renderModel();
    const attempt = {mine: ++request, view: getView(), committing: false};
    pending = attempt;
    cancelAnimationFrame(animation);
    animation = requestAnimationFrame(() => move(attempt));
  }

  slider.oninput = queue;
  details.querySelector('[data-ruler-show]').onclick = queue;
  for (const button of buttons) {
    button.onclick = () => {
      if (button.getAttribute('aria-disabled') === 'true') return;
      slider.value = Number(slider.value) + Number(button.dataset.rulerStep);
      queue();
    };
  }
  details.ontoggle = () => {
    if (details.open) {
      queue();
    } else {
      request++;
      pending = undefined;
      selected = undefined;
      renderModel();
    }
  };

  return {
    cursor,
    show(pair) {
      if (pair?.[0] !== endpoints[0] || pair?.[1] !== endpoints[1]) {
        request++;
        pending = undefined;
        selected = undefined;
        endpoints = pair ? [...pair] : [];
        if (pair) {
          const [a, b] = pair;
          path = crossedVoxels(a.indices, b.indices);
          length = Math.hypot(...b.values.map((value, axis) => value - a.values[axis]));
          slider.max = path.length;
          slider.value = 1;
          if (details.open) queue();
        } else {
          path = undefined;
          details.open = false;
          reading.textContent = '';
        }
      }
      details.hidden = !path;
      const interrupted = pending && !pending.committing && pending.view !== getView();
      if (interrupted) {
        request++;
        pending = undefined;
      }
      if (interrupted || (selected && !cursor())) {
        selected = undefined;
        reading.textContent = 'Section moved. Show a ruler voxel to return to the line.';
      }
    },
  };
}
