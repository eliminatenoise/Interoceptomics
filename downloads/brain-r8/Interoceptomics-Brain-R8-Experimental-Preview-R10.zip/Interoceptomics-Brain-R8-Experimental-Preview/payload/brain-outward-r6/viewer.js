import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {OrbitControls} from './vendor/three/examples/jsm/controls-OrbitControls.js';
const query=new URLSearchParams(location.search),start=performance.now(),width=innerWidth,height=innerHeight;

async function fetchModelFile(path){
 const response=await fetch(path);
 if(!response.ok)throw Error(`${path} returned HTTP ${response.status}`);
 return response;
}

const loading=document.createElement('p');
loading.id='loading';
loading.setAttribute('role','status');
loading.textContent='Loading the 3D model…';
document.body.append(loading);

let startupStep='graphics';
try{
 const renderer=new THREE.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setSize(width,height);renderer.setPixelRatio(1);renderer.setClearColor(0xffffff);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;document.body.append(renderer.domElement);
 startupStep='files';
 const [registry,frame,variantSpec,gltf]=await Promise.all([
  fetchModelFile('./registry.json').then(response=>response.json()),
  fetchModelFile('./camera-r4-bounds.json').then(response=>response.json()),
  fetchModelFile('./variants.json').then(response=>response.json()),
  new GLTFLoader().loadAsync('./assets/brain-source-left-r6.glb'),
 ]);
 const labels=new Map(registry.labels.map(r=>[r.id,r])),nodeInfo=new Map(registry.nodes.map(r=>[r.node,r]));
 const scene=new THREE.Scene();scene.add(gltf.scene);const frameRoot=gltf.scene.getObjectByName('R5_FRAME'),meshes=[];if(!frameRoot)throw Error('Required source-frame root missing');
 gltf.scene.traverse(o=>{if(o.isMesh){o.userData.info=nodeInfo.get(o.name);o.userData.originalMaterial=o.material;meshes.push(o);}});
 async function loadIsolatedTerritory(){
  const info=registry.nodes.find(node=>node.isolation_only);
  if(!info)return;
  try{
   const detail=await new GLTFLoader().loadAsync('./'+info.geometry_file);
   const detailMeshes=[];
   detail.scene.traverse(object=>{if(object.isMesh)detailMeshes.push(object);});
   const [mesh]=detailMeshes;
   if(detailMeshes.length!==1||mesh.name!==info.node||mesh.userData.native_id!==info.native_id
      ||mesh.geometry.attributes.position.count!==info.vertices
      ||mesh.geometry.index?.count!==3*info.triangles)throw Error('Source mesh identity mismatch');
   mesh.userData.info=info;
   mesh.userData.originalMaterial=mesh.material;
   mesh.visible=false;
   frameRoot.add(detail.scene);
   meshes.push(mesh);
  }catch(error){
   console.warn('Separate atlas surface unavailable:',error);
  }
 }
 const surfaceLabelIds=new Set();
 const identityLoads=meshes.map(async o=>{
  const n=o.userData.info;
  if(n.kind!=='existing')return;
  const response=await fetchModelFile('./'+n.vertex_identity_file);
  o.userData.labels=new Uint32Array(await response.arrayBuffer());
  if(o.userData.labels.length!==o.geometry.attributes.position.count)throw Error('Source identity length mismatch');
  for(const id of o.userData.labels)surfaceLabelIds.add(id);
 });
 await Promise.all([...identityLoads,loadIsolatedTerritory()]);
 startupStep='scene';
 const bounds=new THREE.Box3(new THREE.Vector3(...frame.bounds.min),new THREE.Vector3(...frame.bounds.max)),size=bounds.getSize(new THREE.Vector3()),overviewTarget=bounds.getCenter(new THREE.Vector3());overviewTarget.x=0;
 const halfY=Math.max(size.y/2*1.09,size.z/2*(height/width)*1.09),halfX=halfY*width/height;
 const camera=new THREE.OrthographicCamera(-halfX,halfX,halfY,-halfY,.001,10);camera.up.set(0,1,0);
 scene.add(new THREE.HemisphereLight(0xffffff,0x9aa4ab,1.75));
 const rigs=[];for(const [colour,power,offset] of [[0xffffff,1.7,[.6,.32,.35]],[0xe7f0ff,.7,[-.6,.07,-.45]],[0xffffff,.45,[.2,-.1,-.25]]]){const l=new THREE.DirectionalLight(colour,power);l.position.copy(overviewTarget).add(new THREE.Vector3(...offset));scene.add(l);rigs.push({light:l,offset});}
 const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=false;controls.enablePan=true;controls.target.copy(overviewTarget);controls.enabled=query.get('interactive')==='1';
 const state={variant:query.get('variant')||variantSpec.default,view:query.get('view')||'Medial',role:query.get('role')||'all',selection:query.get('select')||'',isolate:query.get('isolate')==='1',qc:query.get('qc')==='all'};
 const descriptions={Medial:'Constructed medial dissection of selected left surfaces. Added deep/opercular masks are not drawn in this preset.',Lateral:'Lateral surface of the same left hemisphere. The insula and deep nuclei remain beneath the overlying surface.',InsulaDissection:'Whole combined cerebral surface hidden to expose the five insular source parcels. This is broader than an opercular removal.',Deep:'Cerebral surface and added insula hidden. Deep source parcels remain in place; overlapping structures can still obscure one another.'};
 const offsets={Medial:[1,0,0],Lateral:[-1,0,0],InsulaDissection:[-1,.12,.28],Deep:[-1,.18,.35]};
 const activeVariant=()=>variantSpec.variants.find(v=>v.key===state.variant);
 function offsetInWorld(a){const v=activeVariant();if(!v)throw Error('Variant is not source-qualified');return new THREE.Vector3(a[0]*v.camera_light_X_factor,a[1],a[2]);}
 function updateFrame(){const v=activeVariant();if(!v)throw Error('Variant is not source-qualified');frameRoot.scale.set(v.frame_root_scale_x,1,1);scene.updateMatrixWorld(true);for(const r of rigs)r.light.position.copy(overviewTarget).add(offsetInWorld(r.offset));}
 const palette={};for(const [k,rgb] of Object.entries(registry.palette))palette[k]=new THREE.Color().setRGB(rgb[0]/255,rgb[1]/255,rgb[2]/255).convertSRGBToLinear();
 const selectedIds=()=>state.selection.startsWith('group:')?new Set(registry.labels.filter(r=>r.state==='new_per_label_mesh'&&r.family===state.selection.slice(6)).map(r=>r.id)):new Set(state.selection?[Number(state.selection)]:[]);
 const selectedMeshes=()=>{const ids=selectedIds();return meshes.filter(o=>o.userData.info.kind==='new'&&ids.has(o.userData.info.native_id));};
 function colours(){if(query.get('stock')==='1'||query.get('asset')==='1'){for(const o of meshes){o.material=o.userData.originalMaterial.clone();o.material.side=query.get('double')==='1'?THREE.DoubleSide:THREE.FrontSide;o.material.flatShading=!o.geometry.hasAttribute('normal');}return;}const chosen=selectedIds(),selectionColour=new THREE.Color(0x34464f);for(const o of meshes){const n=o.userData.info,P=o.geometry.attributes.position,values=new Float32Array(P.count*3),ids=o.userData.labels;for(let i=0;i<P.count;i++){const r=labels.get(n.kind==='new'?n.native_id:ids[i]);let shade=state.role==='anatomy'?'neutral':state.role==='all'?r.default_shade:r.display_tags.includes(state.role)?state.role:'neutral';const c=chosen.has(r.id)&&!state.isolate?selectionColour:palette[shade]||palette.neutral;values.set([c.r,c.g,c.b],i*3);}o.geometry.setAttribute('color',new THREE.BufferAttribute(values,3));o.material?.dispose();o.material=new THREE.MeshStandardMaterial({vertexColors:true,roughness:.83,metalness:0,side:query.get('double')==='1'?THREE.DoubleSide:THREE.FrontSide,flatShading:!o.geometry.hasAttribute('normal')});}}
 function visible(){
  const stock=query.get('stock')==='1',chosen=selectedIds();
  for(const o of meshes){
   const n=o.userData.info;
   let show;
   if(n.isolation_only)show=!stock&&state.isolate&&chosen.has(n.native_id);
   else if(stock)show=true;
   else if(state.isolate&&chosen.size)show=n.kind==='new'&&chosen.has(n.native_id);
   else if(n.kind==='existing')show=(state.view==='Medial'||state.view==='Lateral')||n.source_group!=='cerebral_surface_parcels';
   else show=state.view==='InsulaDissection'?n.family==='insula':state.view==='Deep'?n.family!=='insula':false;
   if(!stock&&n.default_qc_exclusion&&!state.qc)show=false;
   o.visible=show;
  }
 }
 function resetCamera(focus=false){controls.target.copy(overviewTarget);camera.zoom=1;if(focus&&selectedMeshes().length){const box=new THREE.Box3();for(const o of selectedMeshes())box.union(new THREE.Box3().setFromObject(o));const s=box.getSize(new THREE.Vector3());controls.target.copy(box.getCenter(new THREE.Vector3()));camera.zoom=Math.min(12,Math.max(1,halfY*2/(Math.max(s.x,s.y,s.z)*1.35)));}camera.position.copy(controls.target).add(offsetInWorld(offsets[state.view]));camera.lookAt(controls.target);camera.updateProjectionMatrix();controls.update();}
 let axes;
 if(query.get('interactive')==='1'){axes=document.createElementNS('http://www.w3.org/2000/svg','svg');axes.id='axes';axes.setAttribute('viewBox','0 0 110 90');document.body.append(axes);}
 function drawAxes(){if(!axes)return;axes.replaceChildren();for(const [name,v] of [['A',new THREE.Vector3(0,0,1)],['S',new THREE.Vector3(0,1,0)],['R',new THREE.Vector3(-1,0,0)]]){v.applyQuaternion(camera.quaternion.clone().invert());const x=55+v.x*30,y=45-v.y*30,line=document.createElementNS(axes.namespaceURI,'line'),text=document.createElementNS(axes.namespaceURI,'text');for(const [k,val] of Object.entries({x1:55,y1:45,x2:x,y2:y,stroke:'#424c52','stroke-width':1.5}))line.setAttribute(k,val);text.setAttribute('x',x+3);text.setAttribute('y',y-3);text.setAttribute('font-size',12);text.setAttribute('font-family','Arial,Helvetica,sans-serif');text.textContent=name==='R'&&Math.abs(v.z)>.95?(v.z>0?'R ⊙':'R ⊗'):name;axes.append(line,text);}}
 function draw(){renderer.render(scene,camera);drawAxes();}
 controls.addEventListener('change',()=>{draw();publish();});
 function measureVisibility(){const rt=new THREE.WebGLRenderTarget(900,600,{depthBuffer:true});rt.texture.colorSpace=THREE.LinearSRGBColorSpace;const original=meshes.map(o=>o.material);for(let i=0;i<meshes.length;i++){const id=i+1;meshes[i].material=new THREE.MeshBasicMaterial({color:new THREE.Color().setRGB((id&255)/255,(id>>8)/255,0),side:original[i].side,toneMapped:false});}renderer.setRenderTarget(rt);renderer.setClearColor(0);renderer.render(scene,camera);const p=new Uint8Array(900*600*4);renderer.readRenderTargetPixels(rt,0,0,900,600,p);const count={},best={},centres=meshes.map(o=>new THREE.Box3().setFromObject(o).getCenter(new THREE.Vector3()).project(camera));for(let k=0;k<p.length;k+=4){const id=p[k]+(p[k+1]<<8);if(id){count[id]=(count[id]||0)+1;const x=(k/4)%900,y=Math.floor(k/4/900),c=centres[id-1],d=(x+.5-(c.x+1)*450)**2+(y+.5-(c.y+1)*300)**2;if(!best[id]||d<best[id].d)best[id]={x,y,d};}}const result=meshes.map((o,i)=>({node:o.name,kind:o.userData.info.kind,source_ids:o.userData.info.source_ids,drawn:o.visible,pixel_samples:count[i+1]||0,visible_pixel_pick_witness:best[i+1]?{clientX:(best[i+1].x+.5)/900*width,clientY:(1-(best[i+1].y+.5)/600)*height}:null,attribution:o.userData.info.kind==='new'?'single exact source-label mesh':'compound assembly only; not constituent-nucleus visibility'}));meshes.forEach((o,i)=>{o.material.dispose();o.material=original[i];});renderer.setRenderTarget(null);renderer.setClearColor(0xffffff);rt.dispose();draw();return result;}
 const glAudit=renderer.getContext(),frontFaces=new Map();let currentMesh;
 for(const o of meshes)o.onBeforeRender=()=>{currentMesh=o;};
 const nativeDraw=glAudit.drawElements.bind(glAudit);glAudit.drawElements=function(...args){if(currentMesh)frontFaces.set(currentMesh.name,{node:currentMesh.name,world_determinant:currentMesh.matrixWorld.determinant(),gl_front_face:glAudit.getParameter(glAudit.FRONT_FACE)===glAudit.CW?'CW':'CCW',culling:glAudit.isEnabled(glAudit.CULL_FACE),gl_cull_face_mode:glAudit.getParameter(glAudit.CULL_FACE_MODE)===glAudit.BACK?'BACK':glAudit.getParameter(glAudit.CULL_FACE_MODE)===glAudit.FRONT?'FRONT':'FRONT_AND_BACK',material_side:currentMesh.material.side,metallic:currentMesh.material.metalness,roughness:currentMesh.material.roughness});return nativeDraw(...args);};
 function frameMetrics(){scene.updateMatrixWorld(true);camera.updateMatrixWorld(true);const world=new THREE.Matrix3().setFromMatrix4(meshes[0].matrixWorld),B=new THREE.Matrix3().set(-1,0,0,0,0,1,0,1,0),sourceWorld=world.clone().multiply(B),sourceCamera=new THREE.Matrix3().setFromMatrix4(camera.matrixWorldInverse).multiply(sourceWorld);return {rootScale:frameRoot.scale.toArray(),rootWorldMatrixColumnMajor:frameRoot.matrixWorld.toArray(),rootWorldDeterminant:frameRoot.matrixWorld.determinant(),sourceRASdirectionsToWorldColumnMajor:sourceWorld.toArray(),sourceRASdirectionsToWorldDeterminant:sourceWorld.determinant(),sourceRASdirectionsToCameraColumnMajor:sourceCamera.toArray(),sourceRASdirectionsToCameraDeterminant:sourceCamera.determinant(),source_A_screen_horizontal:sourceCamera.elements[3],source_S_screen_vertical_up:sourceCamera.elements[7],cameraRotationDeterminant:new THREE.Matrix3().setFromMatrix4(camera.matrixWorld).determinant(),CSS:[renderer.domElement,document.body,document.documentElement].map(e=>({element:e.tagName,transform:getComputedStyle(e).transform,font:getComputedStyle(e).fontFamily})),drawOrientation:[...frontFaces.values()],visibleWorlds:meshes.filter(o=>o.visible).map(o=>({node:o.name,worldMatrixColumnMajor:o.matrixWorld.toArray(),normalMatrixColumnMajor:o.normalMatrix.toArray(),normalAttribute:o.geometry.hasAttribute('normal'),flatFallback:o.material.flatShading})),lights:rigs.map(r=>({position:r.light.position.toArray(),intensity:r.light.intensity,legacy_offset:r.offset})),shadowMapEnabled:renderer.shadowMap.enabled,castsOrReceivesShadows:meshes.some(o=>o.castShadow||o.receiveShadow),scope:'Actual root/node-world matrices and proper camera. Image top-left row convention is not an anatomy mirror.'};}
 function metrics(measure=false){const gl=renderer.getContext(),dbg=gl.getExtension('WEBGL_debug_renderer_info');const visibility=measure?measureVisibility():null,records=meshes.map(o=>({name:o.name,visible:o.visible,triangles:o.geometry.index.count/3,normal_attribute_present:o.geometry.hasAttribute('normal'),flat_shading:o.material.flatShading}));return {status:'R6_outward_export_candidate_not_independent_acceptance',variant:state.variant,variantLabel:activeVariant().label,view:state.view,role:state.role,selection:state.selection,isolate:state.isolate,qc:state.qc,width,height,source_counts:registry.counts,construction:descriptions[state.view],active_anatomical_half:'original annotated source left',frame:frameMetrics(),fixed_source_principal_framing:state.view==='Medial'&&!state.isolate&&camera.zoom===1&&controls.target.distanceTo(overviewTarget)<1e-12&&camera.position.distanceTo(overviewTarget.clone().add(offsetInWorld([1,0,0])))<1e-12,camera:{worldMatrixColumnMajor:camera.matrixWorld.toArray(),viewMatrixColumnMajor:camera.matrixWorldInverse.toArray(),projectionMatrixColumnMajor:camera.projectionMatrix.toArray(),position:camera.position.toArray(),target:controls.target.toArray(),zoom:camera.zoom,frustum:[camera.left,camera.right,camera.top,camera.bottom]},ordinary_asset_material:query.get('stock')==='1'||query.get('asset')==='1',diagnostic_double_sided:query.get('double')==='1',renderInfo:{calls:renderer.info.render.calls,triangles:renderer.info.render.triangles},renderer:dbg?gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),elapsedMs:performance.now()-start,records,visibility,assemblies:[],visibility_sampling:measure?{width:900,height:600,scope:'Depth-tested mesh IDs, not anatomical/function validation'}:null};}
 function publish(){window.renderMetrics=metrics(false);parent.postMessage({type:'brain-state',state:{...state},variantLabel:activeVariant().label,construction:descriptions[state.view],selectionIds:[...selectedIds()],canIsolate:selectedMeshes().length>0},'*');}
 function apply(command){if(command.variant){state.variant=command.variant;state.isolate=false;updateFrame();}if(command.view){state.view=command.view;state.isolate=false;}if(command.role)state.role=command.role;if('selection'in command)state.selection=String(command.selection);if('isolate'in command)state.isolate=command.isolate;if('qc'in command)state.qc=command.qc;if(state.isolate&&!selectedMeshes().length)state.isolate=false;visible();if(command.variant||command.view||command.role||'selection'in command||'isolate'in command)colours();if(command.variant||command.view||command.reset||command.focus||'isolate'in command)resetCamera(command.focus||state.isolate);draw();publish();}
 window.addEventListener('message',e=>{if(e.source===parent&&e.data?.type==='brain-command')apply(e.data.command);});
 const ray=new THREE.Raycaster(),pointer=new THREE.Vector2();let down;renderer.domElement.addEventListener('pointerdown',e=>{down=[e.clientX,e.clientY];});renderer.domElement.addEventListener('pointerup',e=>{if(query.get('interactive')!=='1'||!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>4)return;pointer.set(e.clientX/width*2-1,-e.clientY/height*2+1);ray.setFromCamera(pointer,camera);const hit=ray.intersectObjects(meshes).find(h=>h.object.visible);if(!hit)return;const n=hit.object.userData.info;if(n.kind==='new')parent.postMessage({type:'brain-pick',id:n.native_id},'*');});
 updateFrame();colours();visible();resetCamera(state.isolate);draw();
 window.brain={renderer,scene,camera,controls,registry,state,frameRoot,variantSpec,apply,draw,measureVisibility,metrics,async isolatedVisibility(){const save={...state};const result=[];for(const r of registry.labels.filter(r=>r.state==='new_per_label_mesh')){state.view=r.family==='insula'?'InsulaDissection':'Deep';state.selection=String(r.id);state.isolate=true;visible();resetCamera(true);draw();const counts=measureVisibility();result.push({id:r.id,name:r.name,camera_zoom:camera.zoom,visible_pixels:counts.find(x=>x.kind==='new'&&x.source_ids[0]===r.id)?.pixel_samples||0,all_other_meshes_hidden:true,overview_and_axes:'UI retains corrected source-left medial overview and proper anatomical axes; source positions unchanged'});}Object.assign(state,save);visible();resetCamera(false);draw();publish();return result;}};
 window.renderMetrics=metrics(query.get('measure')==='1');document.body.dataset.ready='true';publish();if(query.get('measure')==='1')window.renderMetrics=metrics(true);
 loading.remove();
 const separateLabelIds=meshes.filter(o=>o.userData.info.kind==='new').map(o=>o.userData.info.native_id);
 parent.postMessage({type:'brain-ready',separate:separateLabelIds,shared:[...surfaceLabelIds]},location.origin);
}catch(e){
 const errorName=e?.name||'Error',errorMessage=e?.message||String(e);
 const heading={
  graphics:'The browser couldn’t start 3D graphics.',
  files:'The model files couldn’t load.',
  scene:'The 3D view couldn’t open.',
 }[startupStep];
 const help=startupStep==='graphics'
  ?'Try opening the model in a browser with WebGL enabled.'
  :'Reload the viewer. If it still won’t open, extract a fresh copy of the full download and open it with the launcher.';
 document.body.innerHTML='<div id="startup-error"><p id="error" role="alert"></p><p></p><details><summary>Technical details</summary><pre></pre></details></div>';
 document.querySelector('#error').textContent=heading;
 document.querySelector('#startup-error p:nth-child(2)').textContent=help;
 document.querySelector('#startup-error pre').textContent=errorName+': '+errorMessage;
 delete document.body.dataset.ready;
 document.body.dataset.error=e?.stack||errorName+': '+errorMessage;
 parent.postMessage({type:'brain-error'},location.origin);
 throw e;
}
