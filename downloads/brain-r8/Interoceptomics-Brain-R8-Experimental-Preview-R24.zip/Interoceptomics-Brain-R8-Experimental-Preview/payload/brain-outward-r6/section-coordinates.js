export const axes = ['R', 'A', 'S'];
export const sectionNames = ['Sagittal', 'Coronal', 'Axial'];
export const sectionOrder = [1, 0, 2];
export const arrowSteps = {ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowDown: [0, -1], ArrowUp: [0, 1]};

export function formatMm(value) {
  return String(value).replace('-', '−');
}

export function coordinateLabel(coordinate, axis, index) {
  return axes[axis] + ' ' + formatMm(coordinate(axis, index)) + ' mm';
}

export function voxelLabel(coordinate, point) {
  return point.map((index, axis) => axes[axis] + ' ' + formatMm(coordinate(axis, index))).join(' · ') + ' mm';
}

export function setSectionLevels(select, coordinate, {axis, first, stop, selected, fallback}) {
  const options = [];
  for (let index = first; index < stop; index++) {
    options.push(new Option(coordinateLabel(coordinate, axis, index), index));
  }
  select.replaceChildren(...options);
  select.value = selected >= first && selected < stop ? selected : fallback;
}

export function voxelInPlane(point, axis, index, horizontal, vertical) {
  if (point?.[axis] === index) return [point[horizontal], point[vertical]];
}
