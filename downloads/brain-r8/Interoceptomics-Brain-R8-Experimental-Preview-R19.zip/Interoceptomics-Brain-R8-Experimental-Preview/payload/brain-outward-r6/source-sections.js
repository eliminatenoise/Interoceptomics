const axes = ['R', 'A', 'S'];
const directions = ['right', 'anterior', 'superior'];
const front = [1, 0, 2];
const views = [
  {name: 'Sagittal', horizontal: 1, vertical: 2, initial: 171},
  {name: 'Coronal', horizontal: 0, vertical: 2, initial: 227},
  {name: 'Axial', horizontal: 0, vertical: 1, initial: 140},
];

function formatMm(value) {
  return value.toFixed(2).replace(/0$/, '').replace(/\.0$/, '').replace('-', '−');
}

async function loadGrid(comparison) {
  const {file, sha256} = comparison.source_grid;
  const response = await fetch('./' + file, {signal: AbortSignal.timeout(10000)});
  if (!response.ok) throw Error('HTTP ' + response.status);
  const data = await response.arrayBuffer();
  const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
  const hex = Array.from(hash, byte => byte.toString(16).padStart(2, '0')).join('');
  if (hex !== sha256) throw Error('Source grid checksum mismatch');
  const grid = JSON.parse(new TextDecoder().decode(data));
  if (grid.schema !== 1 || grid.annotation_sha256 !== comparison.source_annotation_sha256 ||
      grid.spacing_mm !== comparison.voxel_size_mm ||
      grid.labels.join(',') !== comparison.regions.map(region => region.id).join(',') ||
      grid.shape.reduce((product, length) => product * length, 1) !== grid.cells.length ||
      /[^012]/.test(grid.cells)) throw Error('Unrecognised source grid');
  return grid;
}

export async function makeSourceSections(comparison, elements, onPlane) {
  const grid = await loadGrid(comparison);
  const {orientation, level, canvas, status, directionsLabel} = elements;
  const {start_index: start, shape, ras_origin_mm: origin, cells, spacing_mm: spacing} = grid;
  const mm = (axis, index) => origin[axis] + index * spacing;
  const lower = start.map((index, axis) => mm(axis, index - .5));
  const upper = start.map((index, axis) => mm(axis, index + shape[axis] - .5));
  const previous = views.map(view => view.initial);
  orientation.replaceChildren(...front.map(axis => new Option(views[axis].name, axis)));
  const colours = {1: comparison.regions[0].color, 2: comparison.regions[1].color};
  const ctx = canvas.getContext('2d');
  if (!ctx) throw Error('2D drawing unavailable');

  function draw() {
    const axis = Number(orientation.value);
    const index = Number(level.value);
    previous[axis] = index;
    const view = views[axis];
    const horizontal = view.horizontal;
    const vertical = view.vertical;
    const extent = [shape[horizontal], shape[vertical]];
    const coords = [0, 0, 0];
    coords[axis] = index - start[axis];
    const cell = (h, v) => {
      coords[horizontal] = h;
      coords[vertical] = v;
      return cells[(coords[0] * shape[1] + coords[1]) * shape[2] + coords[2]];
    };
    const width = 284;
    const unit = Math.min(6, 216 / extent[0]);
    const plotWidth = extent[0] * unit;
    const plotHeight = extent[1] * unit;
    const left = 54 + (216 - plotWidth) / 2;
    const top = 17;
    const height = Math.ceil(top + plotHeight + 32);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.ceil(dpr * width);
    canvas.height = Math.ceil(dpr * height);
    ctx.setTransform(canvas.width / width, 0, 0, canvas.height / height, 0, 0);
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = '#f3f5f6';
    ctx.fillRect(left, top, plotWidth, plotHeight);
    const x = h => left + h * unit;
    const y = v => top + plotHeight - v * unit;
    const counts = [0, 0, 0];
    const edges = [];
    function trace(other, here, x1, y1, x2, y2) {
      if (Number(here) + Number(other) === 3) edges.push([x1, y1, x2, y2]);
    }
    for (let h = 0; h < extent[0]; h += 1) {
      for (let v = 0; v < extent[1]; v += 1) {
        const here = cell(h, v);
        counts[here] += 1;
        if (here === '0') continue;
        ctx.fillStyle = colours[here];
        ctx.fillRect(x(h), y(v + 1), unit, unit);
        if (here === '2') {
          ctx.fillStyle = '#fff';
          ctx.fillRect(x(h) + unit * .35, y(v + 1) + unit * .35, unit * .3, unit * .3);
        }
        if (h + 1 < extent[0]) trace(cell(h + 1, v), here, x(h + 1), y(v), x(h + 1), y(v + 1));
        if (v + 1 < extent[1]) trace(cell(h, v + 1), here, x(h), y(v + 1), x(h + 1), y(v + 1));
      }
    }
    ctx.beginPath();
    for (const [x1, y1, x2, y2] of edges) {
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
    }
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.strokeStyle = '#27323a';
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.strokeStyle = '#6b7980';
    ctx.strokeRect(left, top, plotWidth, plotHeight);
    ctx.fillStyle = '#27323a';
    ctx.font = '12px Arial, Helvetica, sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(formatMm(upper[vertical]), left - 5, top + 4);
    ctx.fillText(formatMm(lower[vertical]), left - 5, y(0) + 4);
    ctx.textAlign = 'left';
    ctx.fillText(formatMm(lower[horizontal]), left, y(0) + 16);
    ctx.textAlign = 'right';
    ctx.fillText(formatMm(upper[horizontal]), x(extent[0]), y(0) + 16);
    ctx.textAlign = 'center';
    ctx.fillText(axes[horizontal] + ' (mm)', left + plotWidth / 2, y(0) + 30);
    ctx.save();
    ctx.translate(12, top + plotHeight / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(axes[vertical] + ' (mm)', 0, 0);
    ctx.restore();
    directionsLabel.textContent = 'Towards ' + directions[horizontal] + ' → · Towards ' + directions[vertical] + ' ↑';
    status.textContent = view.name + ' · ' + axes[axis] + ' ' + formatMm(mm(axis, index)) +
      ' mm · VPL ' + counts[1] + ' / VPM ' + counts[2] + ' voxels · ' + edges.length + ' shared edges';
    canvas.setAttribute('aria-label', status.textContent + '. ' +
      axes[horizontal] + ' ranges from ' + formatMm(lower[horizontal]) + ' to ' + formatMm(upper[horizontal]) + ' mm. ' +
      axes[vertical] + ' ranges from ' + formatMm(lower[vertical]) + ' to ' + formatMm(upper[vertical]) + ' mm.');
    onPlane(axis, index);
  }

  function setOrientation() {
    const axis = Number(orientation.value);
    const options = [];
    for (let offset = 1; offset < shape[axis] - 1; offset += 1) {
      const index = start[axis] + offset;
      options.push(new Option(axes[axis] + ' ' + formatMm(mm(axis, index)) + ' mm', index));
    }
    level.replaceChildren(...options);
    level.value = previous[axis];
    draw();
  }

  orientation.onchange = setOrientation;
  level.onchange = draw;
  return {
    open() {
      orientation.value = '1';
      previous.splice(0, previous.length, ...views.map(view => view.initial));
      setOrientation();
    },
  };
}
