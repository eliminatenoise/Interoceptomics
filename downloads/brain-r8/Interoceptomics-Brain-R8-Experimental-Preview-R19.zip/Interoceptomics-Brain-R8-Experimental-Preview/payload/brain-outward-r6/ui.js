const frame = document.querySelector('#model');
const controls = document.querySelector('#model-controls');
const status = document.querySelector('#controls-status');
const select = document.querySelector('#label');
const search = document.querySelector('#search');
const scope = document.querySelector('#scope');
const evidence = document.querySelector('#evidence');
const view = document.querySelector('#view');
const isolate = document.querySelector('#isolate');
const focus = document.querySelector('#focus');
const role = document.querySelector('#role');
const reset = document.querySelector('#reset');
const diagnostic = document.querySelector('#qc');
const comparisonEntry = document.querySelector('#comparison-entry');
const comparisonToggle = document.querySelector('#comparison-toggle');
const comparisonHint = document.querySelector('#comparison-hint');
const comparisonPanel = document.querySelector('#comparison-panel');
const comparisonReturn = document.querySelector('#comparison-return');
const comparisonChoices = document.querySelector('#comparison-choices');
const comparisonLegend = document.querySelector('#comparison-legend');
const comparisonSelected = document.querySelector('#comparison-selected');
const boundaryToggle = document.querySelector('#boundary-toggle');
const boundaryDetails = document.querySelector('#boundary-details');
const boundaryStatus = document.querySelector('#boundary-status');
const sectionsToggle = document.querySelector('#sections-toggle');
const sectionsPanel = document.querySelector('#source-sections');
const sectionsStatus = document.querySelector('#sections-status');
const boundaryKey = document.createElement('span');
boundaryKey.id = 'boundary-key';
boundaryKey.className = 'comparison-region';
boundaryKey.textContent = 'Shared voxel faces';
boundaryKey.hidden = true;
const atlasControls = document.querySelector('#atlas-controls');
const sidebar = document.querySelector('aside');
const narrow = matchMedia('(max-width: 800px)');

const familyNames = {
  insula: 'Insula (all five source labels)',
  amygdaloid: 'Amygdaloid group (all ten occupied labels)',
  basal_ganglia_and_STH: 'Basal ganglia / STH + accumbens context',
  hippocampus: 'Hippocampal head, body and tail',
  basal_forebrain_septal_BNST: 'Basal forebrain + septal / BNST context',
};
let registry;
let available;
let failed = false;
let current = '';
let isolated = false;
let canIsolate = false;
let isolationOnlyLabel;
let qc = false;
let comparing = false;
let beforeComparisonScroll;
let boundaryPhase = 'off';
let sectionsRequested = false;
let sections;
let pendingSections;
const comparisonItems = new Map();

function send(command) {
  if (!controls.disabled) frame.contentWindow.postMessage({type: 'brain-command', command}, location.origin);
}

function name(row) {
  if (row.display_name) return row.display_name;
  return row.name + ([10361, 10338, 10349].includes(row.id) ? ' · labelled residual territory' : '');
}

function options() {
  const term = search.value.toLowerCase();
  const separate = [];
  const shared = [];
  const sourceOnly = [];
  function collect(value, label, searchable, group) {
    if (searchable.toLowerCase().includes(term) || value === current) group.push(new Option(label, value));
  }
  for (const [id, label] of Object.entries(familyNames)) {
    if (registry.labels.some(row => row.state === 'new_per_label_mesh' && row.family === id && available.separate.has(row.id))) {
      collect('group:' + id, label, label, separate);
    }
  }
  for (const row of registry.labels) {
    if (row.state === 'available_omitted') continue;
    const hasSeparate = available.separate.has(row.id) || available.deferred.get(row.id) === 'pending';
    const group = hasSeparate ? separate : available.shared.has(row.id) ? shared : sourceOnly;
    collect(String(row.id), name(row), [name(row), row.name, row.acronym, row.id].join(' '), group);
  }
  select.replaceChildren(new Option('Choose a source territory', ''));
  for (const [label, choices] of [['Separate meshes', separate], ['Surface samples', shared], ['Atlas labels only', sourceOnly]]) {
    if (!choices.length) continue;
    const group = document.createElement('optgroup');
    group.label = label;
    group.append(...choices);
    select.append(group);
  }
  select.value = current;
}

function setIsolation(active) {
  isolated = active;
  document.body.classList.toggle('is-isolated', active || comparing);
  isolate.textContent = isolated ? 'Restore context' : 'Isolate in place';
  isolate.disabled = !canIsolate;
  focus.disabled = !canIsolate || (isolationOnlyLabel && !isolated);
  if (isolationOnlyLabel) {
    if (!canIsolate) {
      const pending = available.deferred.get(isolationOnlyLabel.id) === 'pending';
      scope.textContent = pending
        ? 'Loading the separate atlas surface…'
        : isolationOnlyLabel.load_on_selection
          ? 'The separate atlas surface couldn’t load. Its samples remain visible where the cortical surface is exposed. Reload the atlas to try again.'
          : 'The left atlas label is available. Its separate surface couldn’t load. The rest of the brain is ready to explore.';
    } else if (isolated) {
      scope.textContent = 'The left atlas surface is shown. Drag to turn it. Restore context returns to the full left-hemisphere view.';
    } else {
      scope.textContent = isolationOnlyLabel.isolation_context + ' Choose Isolate in place to see the left atlas surface, then drag to turn it.';
    }
  }
}

function setupComparison() {
  const {regions, shared_faces, voxel_size_mm, overlay} = registry.vpl_vpm_comparison;
  for (const region of regions) {
    const row = registry.labels.find(label => label.id === region.id);
    const button = document.createElement('button');
    const legend = document.createElement('span');
    button.type = 'button';
    button.setAttribute('aria-label', row.name + ' (' + row.acronym + ')');
    button.setAttribute('aria-pressed', 'false');
    for (const item of [button, legend]) {
      item.className = 'comparison-region';
      item.style.setProperty('--region-color', region.color);
      item.textContent = row.acronym;
    }
    button.onclick = () => inspectComparisonRegion(row.id);
    comparisonChoices.append(button);
    comparisonLegend.append(legend);
    comparisonItems.set(row.id, {row, button, legend});
  }
  const area = shared_faces * voxel_size_mm ** 2;
  document.querySelector('#comparison-evidence').textContent =
    'VPL and VPM share ' + shared_faces + ' voxel faces (' + area + ' mm²) on the ' + voxel_size_mm + ' mm left Allen atlas grid.';
  const [right, anterior, superior] = overlay.faces_by_RAS_normal;
  boundaryDetails.textContent =
    'Faces by perpendicular axis. Right–left ' + right + ' · front–back ' + anterior + ' · up–down ' + superior +
    '. Individual anatomy and neural connections require separate evidence.';
  boundaryKey.style.setProperty('--region-color', overlay.color);
  comparisonLegend.append(boundaryKey);
}

function showBoundaryStatus(phase) {
  boundaryPhase = phase;
  const active = phase === 'on';
  boundaryToggle.setAttribute('aria-pressed', String(active));
  boundaryToggle.setAttribute('aria-disabled', String(phase === 'loading' || phase === 'unavailable'));
  boundaryDetails.hidden = boundaryKey.hidden = !active;
  const message = phase === 'loading'
    ? 'Loading shared voxel faces…'
    : phase === 'unavailable' ? 'Shared voxel faces couldn’t load. Reload the atlas to try again.' : '';
  if (boundaryStatus.textContent !== message) boundaryStatus.textContent = message;
}

function collapseSections(clearFrame = true) {
  sectionsRequested = false;
  sectionsPanel.hidden = true;
  sectionsToggle.setAttribute('aria-expanded', 'false');
  sectionsToggle.removeAttribute('aria-disabled');
  sectionsToggle.textContent = 'Show atlas sections';
  sectionsStatus.textContent = '';
  document.body.classList.remove('has-source-section');
  if (clearFrame) send({sourcePlane: null});
}

async function toggleSections() {
  if (sectionsRequested) {
    collapseSections();
    return;
  }
  sectionsRequested = true;
  if (!sections) {
    sectionsStatus.textContent = 'Loading atlas sections…';
    pendingSections ??= import('./source-sections.js').then(({makeSourceSections}) =>
      makeSourceSections(registry.vpl_vpm_comparison, {
        orientation: document.querySelector('#source-orientation'),
        level: document.querySelector('#source-level'),
        canvas: document.querySelector('#source-section-image'),
        status: document.querySelector('#source-section-reading'),
        directionsLabel: document.querySelector('#source-section-directions'),
      }, (axis, index) => send({sourcePlane: {axis, index}}))
    ).catch(error => {
      console.warn('Atlas sections unavailable:', error);
      return null;
    });
    const loaded = await pendingSections;
    if (!sectionsRequested || !comparing) return;
    if (!loaded) {
      collapseSections();
      sectionsToggle.setAttribute('aria-disabled', 'true');
      sectionsStatus.textContent = 'Atlas sections couldn’t load. Reload the atlas to try again.';
      return;
    }
    if (sections) return;
    sections = loaded;
  }
  sectionsPanel.hidden = false;
  document.body.classList.add('has-source-section');
  sectionsToggle.setAttribute('aria-expanded', 'true');
  sectionsToggle.textContent = 'Hide atlas sections';
  sectionsStatus.textContent = '';
  sections.open();
  sectionsToggle.scrollIntoView({block: 'start'});
}

function inspectComparisonRegion(id) {
  const item = comparisonItems.get(id);
  if (!item) return;
  for (const [regionId, {button, legend}] of comparisonItems) {
    button.setAttribute('aria-pressed', String(regionId === id));
    legend.classList.toggle('is-active', regionId === id);
  }
  comparisonSelected.textContent = item.row.name + ' · atlas label ' + item.row.id;
}

function syncComparisonOffer() {
  const visible = comparisonItems.has(Number(current));
  const ready = visible && [...comparisonItems.keys()].every(id => available.separate.has(id));
  comparisonEntry.hidden = !visible;
  comparisonToggle.disabled = !ready;
  comparisonHint.hidden = !visible || ready;
  if (visible && !ready) comparisonToggle.setAttribute('aria-describedby', comparisonHint.id);
  else comparisonToggle.removeAttribute('aria-describedby');
}

function setComparison(active) {
  if (active === comparing || (active && comparisonToggle.disabled)) return;
  if (active) beforeComparisonScroll = { windowY: window.scrollY, sidebarY: sidebar.scrollTop, narrow: narrow.matches };
  if (!active) collapseSections(false);
  comparing = active;
  showBoundaryStatus('off');
  comparisonToggle.setAttribute('aria-expanded', String(active));
  comparisonPanel.hidden = comparisonLegend.hidden = !active;
  atlasControls.hidden = active;
  document.body.classList.toggle('is-comparing', active);
  setIsolation(isolated);
  if (active) {
    inspectComparisonRegion(Number(current));
    comparisonReturn.focus({preventScroll: true});
    sidebar.scrollTop = 0;
    window.scrollTo(0, 0);
  } else {
    const sameLayout = narrow.matches === beforeComparisonScroll.narrow;
    comparisonToggle.focus({preventScroll: sameLayout});
    if (sameLayout) {
      sidebar.scrollTop = beforeComparisonScroll.sidebarY;
      window.scrollTo(0, beforeComparisonScroll.windowY);
    }
    beforeComparisonScroll = undefined;
  }
  send({compare: active});
}

function selection(value) {
  if (controls.disabled) return;
  setComparison(false);
  const wasIsolated = isolated;
  current = String(value);
  const family = current.startsWith('group:') ? current.slice(6) : '';
  const rows = family
    ? registry.labels.filter(row => row.state === 'new_per_label_mesh' && row.family === family)
    : registry.labels.filter(row => row.id === Number(current));
  const row = rows[0];
  const meshes = rows.filter(item => available.separate.has(item.id)).length;
  const shared = row && available.shared.has(row.id);
  canIsolate = meshes > 0;
  isolationOnlyLabel = !family && row?.isolation_only ? row : undefined;

  document.querySelector('#name').textContent = family ? familyNames[family] : row ? name(row) : 'Select a territory';
  const association = !isolationOnlyLabel && (meshes || shared) ? 'Selected overlay' : 'Teaching associations';
  document.querySelector('#tags').textContent = rows.length
    ? association + ' · ' + ([...new Set(rows.flatMap(item => item.display_tags))].join(' / ') || 'neutral context') + ' · nonexclusive'
    : '';
  let instruction = 'Drag to rotate and scroll to zoom. The overview and anatomical axes stay available during isolation.';
  if (family) {
    instruction = meshes + ' separate meshes for ' + rows.length + ' source labels. A parent label covers only its own territory.';
  } else if (meshes) {
    instruction = 'This label has its own surface. Isolate in place hides the surrounding tissue. Focus centres the view on it.';
  } else if (shared) {
    instruction = 'Dark grey marks the samples assigned to this label where they’re exposed. Focus and isolation require a separate mesh.';
  } else if (row) {
    instruction = 'The source atlas names this territory. This model has no labelled surface samples for it.';
  }
  scope.textContent = instruction;
  evidence.textContent = row ? row.overlay_reason + ' ' + row.limits.join(' ') : '';
  const links = document.querySelector('#links');
  links.replaceChildren();
  for (const id of new Set(rows.flatMap(item => item.evidence_source_ids))) {
    const source = Array.isArray(registry.sources) ? registry.sources.find(item => item.id === id) : registry.sources?.[id];
    if (!source) continue;
    const link = document.createElement('a');
    link.textContent = id + ' ' + (source.short_citation || source.citation || source.title || 'Primary source');
    link.href = source.url || source.source_url || source.link;
    link.target = '_blank';
    link.rel = 'noreferrer';
    links.append(link, document.createElement('br'));
  }
  setIsolation(false);
  syncComparisonOffer();

  const command = {selection: current};
  if (wasIsolated || !isolationOnlyLabel) command.isolate = false;
  if (meshes && !isolationOnlyLabel) {
    command.view = row.family === 'insula' ? 'InsulaDissection' : 'Deep';
  } else if (shared && row.existing_group === 'cerebral_surface_parcels' && ['InsulaDissection', 'Deep'].includes(view.value)) {
    command.view = 'Lateral';
  }
  if (command.view) view.value = command.view;
  send(command);
  options();
}

function syncAvailability() {
  const ready = !failed && Boolean(registry && available);
  if (ready && controls.disabled) {
    if (registry.vpl_vpm_comparison) setupComparison();
    options();
  }
  controls.disabled = !ready;
  const message = failed
    ? '3D controls are unavailable. Reload the viewer to try again.'
    : ready ? '3D controls ready.' : '3D controls unlock when the model is ready.';
  if (status.textContent !== message) status.textContent = message;
  status.classList.toggle('visually-hidden', ready);
}

search.oninput = options;
select.onchange = () => selection(select.value);
view.onchange = () => {
  setComparison(false);
  setIsolation(false);
  send({view: view.value});
};
role.onchange = event => send({role: event.target.value});
isolate.onclick = () => {
  setIsolation(!isolated);
  if (document.activeElement === isolate) isolate.scrollIntoView({block: 'nearest'});
  send({isolate: isolated, focus: isolated});
};
focus.onclick = () => send({focus: true});
reset.onclick = () => {
  setIsolation(false);
  send({reset: true, isolate: false});
};
diagnostic.onclick = event => {
  qc = !qc;
  send({qc});
  event.currentTarget.textContent = qc ? 'Hide diagnostic component' : 'Show diagnostic component';
};
comparisonToggle.onclick = () => setComparison(true);
comparisonReturn.onclick = () => setComparison(false);
boundaryToggle.onclick = () => {
  if (boundaryPhase === 'on' || boundaryPhase === 'off') send({boundary: boundaryPhase === 'off'});
};
sectionsToggle.onclick = () => {
  if (comparing && sectionsToggle.getAttribute('aria-disabled') !== 'true') toggleSections();
};
document.querySelector('#comparison-focus').onclick = () => send({focus: true});
for (const button of document.querySelectorAll('[data-comparison-view]')) {
  button.onclick = () => send({comparisonView: button.dataset.comparisonView});
}
addEventListener('keydown', event => {
  if (comparing && event.key === 'Escape') {
    setComparison(false);
    event.preventDefault();
  }
});

addEventListener('message', event => {
  if (event.source !== frame.contentWindow || event.origin !== location.origin) return;
  const message = event.data;
  if (message?.type === 'brain-ready') {
    available = {
      separate: new Set(message.separate), shared: new Set(message.shared),
      deferred: new Map(message.deferred.map(id => [id, 'pending'])),
    };
    syncAvailability();
  } else if (message?.type === 'brain-territory' && available?.deferred.has(message.id)) {
    available.deferred.set(message.id, message.ready ? 'ready' : 'unavailable');
    if (message.ready) available.separate.add(message.id);
    if (current === String(message.id) && !comparing) {
      canIsolate = message.ready;
      setIsolation(isolated);
      options();
    }
  } else if (message?.type === 'brain-error') {
    failed = true;
    syncAvailability();
  } else if (message?.type === 'brain-state') {
    document.querySelector('#construction').textContent = message.construction;
  } else if (message?.type === 'brain-comparison-exit') {
    setComparison(false);
  } else if (message?.type === 'brain-boundary') {
    if (comparing) showBoundaryStatus(message.status);
  } else if (message?.type === 'brain-pick') {
    if (comparing) {
      inspectComparisonRegion(message.id);
      return;
    }
    if (isolationOnlyLabel && isolated && current === String(message.id)) {
      if (isolationOnlyLabel.load_on_selection) evidence.closest('details').open = true;
      return;
    }
    selection(message.id);
  }
});

frame.addEventListener('load', () => {
  const page = frame.contentDocument;
  if (page?.URL === 'about:blank') return;
  if (!page?.body?.hasAttribute('data-brain-viewer')) {
    failed = true;
    syncAvailability();
  }
});
frame.src = frame.dataset.src;

try {
  const response = await fetch('./registry.json');
  if (!response.ok) throw Error('Registry returned HTTP ' + response.status);
  registry = await response.json();
} catch (error) {
  failed = true;
  console.error(error);
}
syncAvailability();
