#!/usr/bin/env python3
"""Serve the preserved brain viewer on a private loopback address."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys
import webbrowser


def main():
    parser = argparse.ArgumentParser(description="Open the Interoceptomics Brain R8 viewer.")
    parser.add_argument("--no-browser", action="store_true", help="Print the local address without opening a browser.")
    options = parser.parse_args()
    root = Path(__file__).resolve().parent / "payload" / "brain-outward-r6"
    if not (root / "index.html").is_file():
        print("The Brain R8 model files are missing. Extract the complete package, then launch it again.", file=sys.stderr)
        return 1
    try:
        server = ThreadingHTTPServer(("127.0.0.1", 0), partial(SimpleHTTPRequestHandler, directory=str(root)))
    except OSError as error:
        print("The local model server could not start: %s" % error, file=sys.stderr)
        return 1
    try:
        url = "http://127.0.0.1:%d/index.html" % server.server_port
        print("Open", url, flush=True)
        if not options.no_browser:
            try:
                opened = webbrowser.open(url)
            except Exception:
                opened = False
            if not opened:
                print("Copy the printed local address into your browser.", flush=True)
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
