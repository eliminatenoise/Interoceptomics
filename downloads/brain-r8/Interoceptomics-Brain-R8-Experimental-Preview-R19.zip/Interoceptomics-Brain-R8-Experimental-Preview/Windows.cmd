@echo off
setlocal
where python3 >nul 2>nul
if errorlevel 1 goto try_python
python3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 goto try_python
python3 -B "%~dp0launch.py" %*
exit /b %errorlevel%
:try_python
where python >nul 2>nul
if errorlevel 1 goto missing_python
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 goto missing_python
python -B "%~dp0launch.py" %*
exit /b %errorlevel%
:missing_python
echo Python 3.10 or newer was not found as python3 or python on PATH.
echo Use an installed Python 3.10+ environment, then run this launcher again. Nothing was installed.
echo Press any key to close this window.
pause >nul
exit /b 127
