# Brain systems share tissue

In either section reader, use **Go to voxel** to enter signed Right, Anterior and Superior coordinates in millimetres. Each value must land on a 0.5 mm centre. The reader can open another available plane and widen the PaO window to show the point.

Select a voxel and choose **Copy saved view**. Paste the fragment into **Open saved view** after launching the atlas on any local port. You can also append it to the viewer’s address in the browser. The fragment carries the territory, plane, window and exact RAS voxel centre. The reader reopens the marked voxel and places the violet frame at the same section bounds. The camera uses the territory’s starting view.

Choose **Set A** at one marked voxel and **Set B** at another. Either slot can be replaced. The RAS differences are B minus A. The straight line joins the two centres in the same atlas grid. Filled marks carry a source label. An open ring may mark an unlabelled voxel in PaO or a tile outside the two available labels in the VPL/VPM crop. The current plane only shows marks at its own level and within its bounds. In 3D, the marks can be at different levels within the current window. Use **Clear A and B** to start again.

Open **Follow the ruler through sections** to see how far the line travels under each label. The rows give the boundaries from A and the length inside each contiguous run. Choose a row to go to its first voxel. The source label still appears when the active reader lacks a section there. The amber cross marks a voxel centre where it fits in the 3D window.

Choose **Copy measurement** after setting both points. The fragment carries where you marked A, where you marked B and the section you had open when you copied it. Paste it into **Open saved view** on another launch of the atlas, even on a different local port. The reader checks the Allen annotation and grid and computes the displacement and distance from the two centres. The browser keeps the fragment local. If the clipboard is blocked, select and copy the text under the button.

**Restore context** returns to the selected view at its starting angle and zoom. Medial returns to the constructed dissection. **Focus** centres and zooms to the selection from the view’s starting angle. **Reset view** ends isolation and keeps the selection. In the thalamus comparison, **Return to prior view** restores the camera you had before opening it.

Search for **PaO** (13230) for the left parietal operculum. **Show parietal operculum sections** opens the original 0.5 mm Allen labels. The opening coronal slice at A −18 mm crosses the fold where it meets the long insular gyri. Step through the layers or select **Full atlas plane** to see the whole source rectangle at the same level. Select a tile or use the arrow keys on the image. Change the section plane to see the same voxel from another direction. If the atlas level is missing, the reader gives the voxel’s coordinate and hides its marker. If the point is outside the neighbourhood window, choose Full atlas plane to see it. **Frame section in 3D** frames the same atlas window. The source coordinate system and photo comparisons are on the [source page](source.html#pao-sections). The separate surface loads when selected. Choose **Isolate in place** to lift away the surrounding tissue, or open **Evidence and limits** to read how the atlas label compares with histological fields and touch studies.

This research companion shows the original annotated left half. In the medial view, anterior is to the right; in the lateral view, anterior is to the left. Anatomical axes and the fixed medial overview remain available during rotation, zoom and isolation.

Blue, copper and purple mark selected somatic, autonomic and integration associations. Those associations overlap. Grey tissue can participate too. The colours select teaching examples rather than measuring activity or complete functional boundaries.

The model includes 121 of 141 occupied source labels. The original brain asset supplies thirty separate source-label meshes: five insular, ten amygdaloid, nine basal-ganglia/subthalamic/accumbens, three hippocampal, and three basal-forebrain/septal/bed-nucleus territories. Separate left meshes for the red nucleus, ventral posterior lateral nucleus (VPL), ventral posterior medial nucleus (VPM) and parietal operculum bring the total to thirty-four. Select a nucleus and choose **Isolate in place** to see the internal surface. **Restore context** brings back the current view. Twenty labels remain absent. Existing combined surfaces cannot isolate every constituent nucleus. Parent-labelled amygdaloid, putaminal and basal-forebrain territory is residual; selecting the whole group combines all its occupied labels.

Select **VPL** or **VPM**, then **Compare VPL and VPM**. Blue and copper identify the two territories. Turn them together, pick either surface or use the labelled buttons. **From front**, **From above** and **Frame both** adjust the camera. **Return to prior view** or Escape restores the selection, camera and context. Both meshes must load for this view.

Choose **Show shared voxel faces** to see the gold boundary through the transparent surfaces. Press again to see the opaque surfaces at the same angle.

Choose **Show atlas sections** to follow the same boundary one voxel layer at a time. Pick a plane and atlas level. The violet frame shows where the section sits in 3D. Select a tile or use the arrow keys on the image to read its label and voxel-centre coordinates. Change the section plane to see the same voxel from another direction. If its level falls outside the list, the readout gives that coordinate and the marker disappears. Return to a plane that contains the voxel and the marker comes back. The crop keeps the VPL and VPM labels. Grey tiles may lie in other atlas territories.

VPM follows the inner edge of VPL. Their labels touch across 481 square faces on the original 0.5 mm left Allen atlas grid. Added together, the faces cover 120.25 mm² on that grid. Edge and corner contacts contribute no area. The stair-step outline and the area follow the atlas grid. Individual anatomy, registered contours and neural connections require separate evidence.

The insular view hides the whole combined cerebral surface, broader than surgical opercular removal. The deep view also hides the added insula. Structures stay in place, and some still obscure one another. Isolation changes drawing and camera only. Habenular, pineal and zona incerta contexts retain neutral overlays within a combined central surface.

The source uses 0.5 mm voxels. Earlier surface derivation used a declared midline cap of at most 0.25 mm and a display approximation of at most 0.125 mm relative to raw capped surfaces. The R6 brain asset bakes the proper source-to-world frame into the model and corrects the coherent surface-normal direction. The unsmoothed red nucleus, VPL and VPM surfaces follow atlas labels 12247, 10424 and 10425 in the same coordinates. The atlas names a parvocellular division (VPMpc) without giving it separate voxels in version 1. These bounds describe the derivative, not biological accuracy. Fine autonomic nuclei, cortical functional fields and individual cerebellar deep nuclei remain unresolved. Independent basal-forebrain/septal/bed-nucleus shape confirmation remains open.

The export and companion use ordinary single-sided material. Local source-grid, display-field and smoothed-normal disagreements remain in the technical evidence; the correction does not establish exact biological boundaries. All source components and contact limits remain preserved. Two remote hypothalamic-labelled source voxels remain available through Source QC, with their 16 triangles excluded from the default drawing.

Run a local server in this folder:

    python3 -m http.server 8765 --bind 127.0.0.1

Then open `http://127.0.0.1:8765/index.html`. All rendering dependencies are included. Citation links open their original websites. A modern WebGL browser is required.

Attribution: Song-Lin Ding, Joshua J. Royall, Susan M. Sunkin, Benjamin A. C. Facer, Phil Lesnar, Amy Bernard, Lydia Ng and Ed S. Lein (2020), *Allen Human Reference Atlas — 3D, 2020*, version 1.0.0, RRID:SCR_017764; copyright © 2019 Allen Institute for Brain Science. Source: https://download.alleninstitute.org/informatics-archive/allen_human_reference_atlas_3d_2020/version_1/ . The source README states CC BY 4.0 effective September 1, 2022: https://creativecommons.org/licenses/by/4.0/ . Retain attribution and identify changes on reuse. No endorsement is implied.

Changes across the derivative: selection of source centres at native RAS R≤0; midline cap; source-grid extraction; bounded display approximation and normal treatment; structural unions plus thirty source-label masks in the R6 brain asset and separate left red nucleus, VPL and VPM surfaces; selected association colours; cameras, lighting and interaction. This edition bakes the proper frame into positions with identity nodes and supplies single-sided matte material. The complete source-to-world map is a proper basis conversion, C(R,A,S)=(-R,S,A)/1000: world −X is anatomical right, +Y superior and +Z anterior. The left source domain is defined in native RAS, not by a world-X assumption. There is no right-half option in this candidate.

The atlas was drawn on the ICBM 2009b nonlinear symmetric MNI152 average. It is not a measured individual's brain or a donor-specific body fit. The source README identifies the McConnell Brain Imaging Centre reference and its separate terms; no underlying MRI is redistributed. The current graph16 ontology was retrieved November 4, 2026, rather than recovered as a frozen 2020 graph. All 141 observed IDs resolve. Three.js retains its MIT notice in `vendor/three/LICENSE`. Full source, coordinate, preserved mirror-qualification, boundary-direction countercases and verification records accompany the candidate separately.

Comparison sources: https://pmc.ncbi.nlm.nih.gov/articles/PMC5054943/ (Ding et al., 2016; source histology/nomenclature, with erratum https://doi.org/10.1002/cne.24130); https://pmc.ncbi.nlm.nih.gov/articles/PMC3171658/ (Wang et al., 2011); https://doi.org/10.4274/imj.galenos.2020.09633 (Güdük et al., 2020); https://doi.org/10.3389/fnana.2020.00013 (Emmi et al., 2020). Tissue images informed gross anatomical comparison, with different exposures and registration limits. Those images are excluded from the companion. Neither frame correction nor rendering establishes complete anatomical or functional accuracy.

Stored vertex colours retain their original values. The companion applies its authored sRGB identification palette; ordinary glTF software treats vertex colours as linear and may show lighter shades. The colour-transfer difference is documented, and stock-export pixel identity is not claimed.

### Full atlas label planes

Choose **Explore full atlas labels** to read three cuts through a single voxel.
Each view comes from the native Allen annotation and follows its 0.5 mm qform.
On the coronal and axial cuts, anatomical left is at screen left. Pick a tile,
move with the arrow keys or enter an exact RAS centre in millimetres. The label
name and ID come from the original atlas. Pick a voxel in a supplied PaO or
VPL/VPM section and choose **Open full atlas at this voxel** to continue from
its exact location. Return to atlas controls to pick up the same section or ruler.

The three views can show native labels beyond the supplied crop or section levels,
including sparse labelled source-right voxels. The 3D preview uses the source-left
frame. A teal cross marks a labelled left voxel in that frame when the camera can
see its coordinate. Colour is a visual key only. These cuts do not contain tissue
imagery or MRI intensity. **Copy saved view** records the grid identity and voxel
index for a later launch. [Source and axes](source.html#annotation-planes).
