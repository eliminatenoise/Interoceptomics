const frame = document.querySelector('#model');
const controls = document.querySelector('#model-controls');
const status = document.querySelector('#controls-status');
const select = document.querySelector('#label');
const search = document.querySelector('#search');
const view = document.querySelector('#view');
const isolate = document.querySelector('#isolate');
const focus = document.querySelector('#focus');

const familyNames = {
  insula: 'Insula (all five source labels)',
  amygdaloid: 'Amygdaloid group (all ten occupied labels)',
  basal_ganglia_and_STH: 'Basal ganglia / STH + accumbens context',
  hippocampus: 'Hippocampal head, body and tail',
  basal_forebrain_septal_BNST: 'Basal forebrain + septal / BNST context',
};
let registry;
let available;
let failed = false;
let current = '';
let isolated = false;
let canIsolate = false;
let isolationOnlyLabel;
let qc = false;

function send(command) {
  if (!controls.disabled) frame.contentWindow.postMessage({type: 'brain-command', command}, location.origin);
}

function name(row) {
  if (row.display_name) return row.display_name;
  return row.name + ([10361, 10338, 10349].includes(row.id) ? ' · labelled residual territory' : '');
}

function options() {
  const term = search.value.toLowerCase();
  const separate = [];
  const shared = [];
  const sourceOnly = [];
  function collect(value, label, searchable, group) {
    if (searchable.toLowerCase().includes(term) || value === current) group.push(new Option(label, value));
  }
  for (const [id, label] of Object.entries(familyNames)) {
    if (registry.labels.some(row => row.state === 'new_per_label_mesh' && row.family === id && available.separate.has(row.id))) {
      collect('group:' + id, label, label, separate);
    }
  }
  for (const row of registry.labels) {
    if (row.state === 'available_omitted') continue;
    const group = available.separate.has(row.id) ? separate : available.shared.has(row.id) ? shared : sourceOnly;
    collect(String(row.id), name(row), [name(row), row.name, row.acronym, row.id].join(' '), group);
  }
  select.replaceChildren(new Option('Choose a source territory', ''));
  for (const [label, choices] of [['Separate meshes', separate], ['Surface samples', shared], ['Atlas labels only', sourceOnly]]) {
    if (!choices.length) continue;
    const group = document.createElement('optgroup');
    group.label = label;
    group.append(...choices);
    select.append(group);
  }
  select.value = current;
}

function setIsolation(active) {
  isolated = active;
  document.body.classList.toggle('is-isolated', active);
  isolate.textContent = isolated ? 'Restore context' : 'Isolate in place';
  isolate.disabled = !canIsolate;
  focus.disabled = !canIsolate || (isolationOnlyLabel && !isolated);
  if (isolationOnlyLabel) {
    const scope = document.querySelector('#scope');
    if (!canIsolate) {
      scope.textContent = 'The left atlas label is available. Its separate surface couldn’t load. The rest of the brain is ready to explore.';
    } else if (isolated) {
      scope.textContent = 'The left atlas surface is shown. Drag to turn it. Restore context returns to the full left-hemisphere view.';
    } else {
      scope.textContent = isolationOnlyLabel.isolation_context + ' Choose Isolate in place to see the left atlas surface, then drag to turn it.';
    }
  }
}

function selection(value) {
  if (controls.disabled) return;
  const wasIsolated = isolated;
  current = String(value);
  const family = current.startsWith('group:') ? current.slice(6) : '';
  const rows = family
    ? registry.labels.filter(row => row.state === 'new_per_label_mesh' && row.family === family)
    : registry.labels.filter(row => row.id === Number(current));
  const row = rows[0];
  const meshes = rows.filter(item => available.separate.has(item.id)).length;
  const shared = row && available.shared.has(row.id);
  canIsolate = meshes > 0;
  isolationOnlyLabel = !family && row?.isolation_only ? row : undefined;

  document.querySelector('#name').textContent = family ? familyNames[family] : row ? name(row) : 'Select a territory';
  const association = !isolationOnlyLabel && (meshes || shared) ? 'Selected overlay' : 'Teaching associations';
  document.querySelector('#tags').textContent = rows.length
    ? association + ' · ' + ([...new Set(rows.flatMap(item => item.display_tags))].join(' / ') || 'neutral context') + ' · nonexclusive'
    : '';
  let scope = 'Drag to rotate and scroll to zoom. The overview and anatomical axes stay available during isolation.';
  if (family) {
    scope = meshes + ' separate meshes for ' + rows.length + ' source labels. A parent label covers only its own territory.';
  } else if (meshes) {
    scope = 'This label has its own surface. Isolate in place hides the surrounding tissue. Focus centres the view on it.';
  } else if (shared) {
    scope = 'Dark grey marks the samples assigned to this label where they’re exposed. Focus and isolation require a separate mesh.';
  } else if (row) {
    scope = 'The source atlas names this territory. This model has no labelled surface samples for it.';
  }
  document.querySelector('#scope').textContent = scope;
  document.querySelector('#evidence').textContent = row ? row.overlay_reason + ' ' + row.limits.join(' ') : '';
  const links = document.querySelector('#links');
  links.replaceChildren();
  for (const id of new Set(rows.flatMap(item => item.evidence_source_ids))) {
    const source = Array.isArray(registry.sources) ? registry.sources.find(item => item.id === id) : registry.sources?.[id];
    if (!source) continue;
    const link = document.createElement('a');
    link.textContent = id + ' ' + (source.short_citation || source.citation || source.title || 'Primary source');
    link.href = source.url || source.source_url || source.link;
    link.target = '_blank';
    link.rel = 'noreferrer';
    links.append(link, document.createElement('br'));
  }
  setIsolation(false);

  const command = {selection: current};
  if (wasIsolated || !isolationOnlyLabel) command.isolate = false;
  if (meshes && !isolationOnlyLabel) {
    command.view = row.family === 'insula' ? 'InsulaDissection' : 'Deep';
  } else if (shared && row.existing_group === 'cerebral_surface_parcels' && ['InsulaDissection', 'Deep'].includes(view.value)) {
    command.view = 'Lateral';
  }
  if (command.view) view.value = command.view;
  send(command);
  options();
}

function syncAvailability() {
  const ready = !failed && Boolean(registry && available);
  if (ready && controls.disabled) options();
  controls.disabled = !ready;
  const message = failed
    ? '3D controls are unavailable. Reload the viewer to try again.'
    : ready ? '3D controls ready.' : '3D controls unlock when the model is ready.';
  if (status.textContent !== message) status.textContent = message;
  status.classList.toggle('visually-hidden', ready);
}

search.oninput = options;
select.onchange = () => selection(select.value);
view.onchange = () => {
  setIsolation(false);
  send({view: view.value});
};
document.querySelector('#role').onchange = event => send({role: event.target.value});
isolate.onclick = () => {
  setIsolation(!isolated);
  if (document.activeElement === isolate) isolate.scrollIntoView({block: 'nearest'});
  send({isolate: isolated, focus: isolated});
};
focus.onclick = () => send({focus: true});
document.querySelector('#reset').onclick = () => {
  setIsolation(false);
  send({reset: true, isolate: false});
};
document.querySelector('#qc').onclick = event => {
  qc = !qc;
  send({qc});
  event.currentTarget.textContent = qc ? 'Hide diagnostic component' : 'Show diagnostic component';
};

addEventListener('message', event => {
  if (event.source !== frame.contentWindow || event.origin !== location.origin) return;
  const message = event.data;
  if (message?.type === 'brain-ready') {
    available = {separate: new Set(message.separate), shared: new Set(message.shared)};
    syncAvailability();
  } else if (message?.type === 'brain-error') {
    failed = true;
    syncAvailability();
  } else if (message?.type === 'brain-state') {
    document.querySelector('#construction').textContent = message.construction;
  } else if (message?.type === 'brain-pick') {
    if (isolationOnlyLabel && isolated && current === String(message.id)) return;
    selection(message.id);
  }
});

frame.addEventListener('load', () => {
  const page = frame.contentDocument;
  if (page?.URL === 'about:blank') return;
  if (!page?.body?.hasAttribute('data-brain-viewer')) {
    failed = true;
    syncAvailability();
  }
});
frame.src = frame.dataset.src;

try {
  const response = await fetch('./registry.json');
  if (!response.ok) throw Error('Registry returned HTTP ' + response.status);
  registry = await response.json();
} catch (error) {
  failed = true;
  console.error(error);
}
syncAvailability();
