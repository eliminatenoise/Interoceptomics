const axes = ['R', 'A', 'S'];
const directions = ['Right', 'Anterior', 'Superior'];
const names = ['Sagittal', 'Coronal', 'Axial'];
const neighbourhood = [
  [13230, '#654495'],
  [12177, '#147b72'],
  [12144, '#b6572d'],
  [12132, '#2c6896'],
  [12135, '#8a4963'],
  [12127, '#8a702c'],
];
const colours = new Map(neighbourhood);
const decoder = new TextDecoder();

async function checkedFile({file, sha256, bytes}) {
  const response = await fetch('./' + file, {signal: AbortSignal.timeout(10000)});
  if (!response.ok) throw Error('HTTP ' + response.status);
  const data = await response.arrayBuffer();
  if (data.byteLength !== bytes) throw Error('Section file length mismatch');
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', data));
  if (Array.from(digest, byte => byte.toString(16).padStart(2, '0')).join('') !== sha256) {
    throw Error('Section file checksum mismatch');
  }
  return data;
}

function decodePlane(data, start, end, size, labels) {
  const encoded = new DataView(data, start, end - start);
  const cells = new Uint32Array(size);
  let next = 0;
  for (let i = 0; i < encoded.byteLength; i += 8) {
    const count = encoded.getUint32(i, true);
    const label = encoded.getUint32(i + 4, true);
    if (!count || next + count > size || !Object.hasOwn(labels, label)) throw Error('Invalid voxel run');
    cells.fill(label, next, next + count);
    next += count;
  }
  if (next !== size) throw Error('Incomplete plane');
  return cells;
}

function mm(value) {
  return String(value).replace('-', '−');
}

export async function makeParietalSections(spec, elements, onPlane) {
  const index = JSON.parse(decoder.decode(await checkedFile(spec)));
  if (index.schema !== 1 || index.annotation_sha256 !== spec.annotation_sha256 ||
      index.voxel_size_mm !== spec.voxel_size_mm || index.target_id !== spec.target_id ||
      !Array.isArray(index.planes) || index.planes.length !== 3) throw Error('Unrecognised annotation index');
  const {atlas_shape: shape, ras_origin_mm: origin, voxel_size_mm: spacing, labels, target_id: target} = index;
  const {orientation, level, extent, highlight, key, canvas, reading, bounds, voxel, status, frame} = elements;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw Error('2D drawing unavailable');
  const files = new Map();
  const rgb = new Map(neighbourhood.map(([id, value]) => [id,
    value.slice(1).match(/../g).map(component => parseInt(component, 16))]));
  const coordinate = (axis, offset) => origin[axis] + spacing * offset;
  const previous = index.planes.map(plane => plane.initial_index);
  let request = 0;
  let active = false;
  let plane;
  let cells;
  let hStart, hStop, vStart, vStop;
  let cursor;
  let showCursor = false;
  let image;

  function handleVoxel(h, v, mark = true) {
    cursor = [h, v];
    ctx.putImageData(image, 0, 0);
    showCursor = mark;
    if (mark) {
      const col = h - hStart + .5;
      const row = vStop - v - .5;
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 3;
      ctx.strokeRect(col - 3, row - 3, 6, 6);
      ctx.strokeStyle = '#19232c';
      ctx.lineWidth = 1;
      ctx.strokeRect(col - 3, row - 3, 6, 6);
    }
    const {axis, horizontal, vertical} = plane;
    const labelId = cells[v * shape[horizontal] + h];
    const [acronym, name] = labels[labelId];
    const point = [];
    point[axis] = coordinate(axis, previous[axis]);
    point[horizontal] = coordinate(horizontal, h);
    point[vertical] = coordinate(vertical, v);
    voxel.textContent = point.map((value, dim) => axes[dim] + ' ' + mm(value)).join(' · ') +
      ' mm · ' + name + (labelId ? ' (' + acronym + ', ' + labelId + ')' : '');
  }

  function draw(moveFrame = true) {
    if (!active || !cells) return;
    const {axis, horizontal, vertical} = plane;
    const full = extent.value === 'full';
    const start = full ? [0, 0, 0] : index.focus_start_index;
    const stop = full ? shape : index.focus_stop_index;
    hStart = start[horizontal];
    hStop = stop[horizontal];
    vStart = start[vertical];
    vStop = stop[vertical];
    canvas.width = hStop - hStart;
    canvas.height = vStop - vStart;
    image = ctx.createImageData(canvas.width, canvas.height);
    const counts = new Map();
    const selected = Number(highlight.value);
    const accent = [0, 101, 103];
    const tissue = [203, 210, 219];
    const outside = [246, 248, 250];
    let pixel = 0;
    let firstTarget;
    for (let v = vStop - 1; v >= vStart; v--) {
      for (let h = hStart; h < hStop; h++) {
        const id = cells[v * shape[horizontal] + h];
        counts.set(id, (counts.get(id) || 0) + 1);
        if (id === target && !firstTarget) firstTarget = [h, v];
        const [red, green, blue] = id === selected && selected !== target ? accent :
          rgb.get(id) || (id ? tissue : outside);
        image.data[pixel++] = red;
        image.data[pixel++] = green;
        image.data[pixel++] = blue;
        image.data[pixel++] = 255;
      }
    }
    const sorted = [...counts].filter(([id]) => id && id !== target)
      .sort(([a], [b]) => labels[a][1].localeCompare(labels[b][1], 'en'));
    highlight.replaceChildren(new Option('PaO and nearby labels', target),
      ...sorted.map(([id, count]) => new Option(labels[id][1] + ' (' + labels[id][0] + ') · ' + count, id)));
    highlight.value = counts.has(selected) && selected ? selected : target;
    const nearby = neighbourhood.filter(([id]) => counts.has(id));
    key.replaceChildren(...nearby.map(([id, colour]) => {
      const item = document.createElement('li');
      item.style.setProperty('--region-color', id === Number(highlight.value) && id !== target ? '#006567' : colour);
      item.textContent = labels[id][1];
      return item;
    }));
    const chosen = Number(highlight.value);
    if (chosen !== target && !colours.has(chosen)) {
      const item = document.createElement('li');
      item.style.setProperty('--region-color', '#006567');
      item.textContent = labels[chosen][1];
      key.append(item);
    }
    reading.textContent = names[axis] + ' · ' + axes[axis] + ' ' + mm(coordinate(axis, previous[axis])) +
      ' mm · ' + (counts.get(target) || 0) + ' PaO voxels';
    const displayBounds = (dim, low, high) => mm(coordinate(dim, low - .5)) + ' to ' + mm(coordinate(dim, high - .5)) + ' mm';
    bounds.textContent = directions[horizontal] + ' → ' + displayBounds(horizontal, hStart, hStop) +
      ' · ' + directions[vertical] + ' ↑ ' + displayBounds(vertical, vStart, vStop);
    const sameWindow = cursor && cursor[0] >= hStart && cursor[0] < hStop && cursor[1] >= vStart && cursor[1] < vStop;
    cursor = sameWindow ? cursor : firstTarget;
    if (moveFrame) onPlane({axis, index: previous[axis], full});
    handleVoxel(...(cursor || firstTarget || [hStart, vStart]), Boolean(sameWindow && showCursor));
  }

  function setReady(ready) {
    frame.disabled = highlight.disabled = extent.disabled = !ready;
    canvas.tabIndex = ready ? 0 : -1;
    canvas.closest('figure').hidden = canvas.hidden = !ready;
    if (!ready) {
      reading.textContent = bounds.textContent = voxel.textContent = '';
      key.replaceChildren();
    }
  }

  async function setLevel() {
    const mine = ++request;
    const next = index.planes[Number(orientation.value)];
    const selected = Number(level.value);
    previous[next.axis] = selected;
    if (plane?.axis !== next.axis) cursor = undefined;
    const [start, end] = next.byte_offsets.slice(selected - next.first_index, selected - next.first_index + 2);
    try {
      let file = files.get(next.axis);
      if (!(file instanceof ArrayBuffer)) {
        if (!file) {
          file = checkedFile(next).then(data => {
            files.set(next.axis, data);
            return data;
          }, error => {
            files.delete(next.axis);
            throw error;
          });
          files.set(next.axis, file);
        }
        setReady(false);
        onPlane(null);
        status.textContent = 'Loading ' + next.name + ' sections…';
        file = await file;
      }
      if (!active || mine !== request) return;
      if (!Number.isInteger(start) || !Number.isInteger(end) || start < 0 || end > file.byteLength ||
          end <= start || (end - start) % 8 !== 0) throw Error('Invalid section offset');
      cells = decodePlane(file, start, end, shape[next.horizontal] * shape[next.vertical], labels);
      plane = next;
      status.textContent = '';
      setReady(true);
      draw();
    } catch (error) {
      if (active && mine === request) {
        setReady(false);
        onPlane(null);
        status.textContent = 'This section couldn’t load. Change the plane or reopen the sections to try again.';
        console.warn('Parietal operculum section unavailable:', error);
      }
    }
  }

  function setOrientation() {
    const {axis, first_index: first, stop_index: stop} = index.planes[Number(orientation.value)];
    const levels = [];
    for (let offset = first; offset < stop; offset++) {
      levels.push(new Option(axes[axis] + ' ' + mm(coordinate(axis, offset)) + ' mm', offset));
    }
    level.replaceChildren(...levels);
    level.value = previous[axis];
    setLevel();
  }

  orientation.replaceChildren(...[1, 0, 2].map(axis => new Option(names[axis], axis)));
  orientation.onchange = setOrientation;
  level.onchange = setLevel;
  extent.onchange = () => draw();
  highlight.onchange = () => draw(false);
  canvas.onclick = event => {
    const rect = canvas.getBoundingClientRect();
    const h = Math.min(canvas.width - 1, Math.max(0, Math.floor((event.clientX - rect.left) / rect.width * canvas.width)));
    const v = Math.min(canvas.height - 1, Math.max(0, Math.floor((event.clientY - rect.top) / rect.height * canvas.height)));
    handleVoxel(hStart + h, vStop - 1 - v);
  };
  canvas.onkeydown = event => {
    const delta = {ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowDown: [0, -1], ArrowUp: [0, 1]}[event.key];
    if (!delta) return;
    event.preventDefault();
    handleVoxel(
      Math.max(hStart, Math.min(hStop - 1, cursor[0] + delta[0])),
      Math.max(vStart, Math.min(vStop - 1, cursor[1] + delta[1]))
    );
  };
  frame.onclick = () => onPlane({axis: plane.axis, index: previous[plane.axis], full: extent.value === 'full', frame: true});
  return {
    open() {
      active = true;
      orientation.value = '1';
      extent.value = 'near';
      highlight.value = target;
      cursor = undefined;
      showCursor = false;
      setOrientation();
    },
    close() {
      active = false;
      request++;
      status.textContent = '';
      onPlane(null);
    },
  };
}
