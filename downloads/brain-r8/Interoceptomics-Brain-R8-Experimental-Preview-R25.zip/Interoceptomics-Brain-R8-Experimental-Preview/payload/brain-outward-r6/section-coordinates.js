export const axes = ['R', 'A', 'S'];
export const sectionNames = ['Sagittal', 'Coronal', 'Axial'];
export const sectionOrder = [1, 0, 2];
export const arrowSteps = {ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowDown: [0, -1], ArrowUp: [0, 1]};

export function formatMm(value) {
  return String(value).replace('-', '−');
}

export function coordinateLabel(coordinate, axis, index) {
  return axes[axis] + ' ' + formatMm(coordinate(axis, index)) + ' mm';
}

export function voxelLabel(coordinate, point) {
  return point.map((index, axis) => axes[axis] + ' ' + formatMm(coordinate(axis, index))).join(' · ') + ' mm';
}

export function setSectionLevels(select, coordinate, {axis, first, stop, selected, fallback}) {
  const options = [];
  for (let index = first; index < stop; index++) {
    options.push(new Option(coordinateLabel(coordinate, axis, index), index));
  }
  select.replaceChildren(...options);
  select.value = selected >= first && selected < stop ? selected : fallback;
}

export function voxelInPlane(point, axis, index, horizontal, vertical) {
  if (point?.[axis] === index) return [point[horizontal], point[vertical]];
}

export function availableSectionAxis(point, current, levels) {
  return [current, ...sectionOrder].find(axis =>
    point[axis] >= levels[axis].first && point[axis] < levels[axis].stop
  );
}

export function bindCoordinateJump(form, {start, stop, coordinate, outside, jump}) {
  const inputs = axes.map(axis => form.elements.namedItem(axis));
  const status = form.querySelector('[role="status"]');
  const report = (message, field) => {
    status.textContent = message;
    field?.setAttribute('aria-invalid', 'true');
  };

  form.onsubmit = event => {
    event.preventDefault();
    for (const field of inputs) field.removeAttribute('aria-invalid');
    const point = [];
    for (const [axis, field] of inputs.entries()) {
      const value = field.value.trim().replace(/^−/, '-');
      if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(value)) {
        report('Enter ' + axes[axis] + ' as a decimal number in mm.', field);
        return;
      }
      // Check the typed fraction before converting to binary floating point.
      // A long decimal near a half millimetre must not round to a grid centre.
      if (!/^(?:0*|50*)$/.test(value.split('.')[1] ?? '')) {
        report(axes[axis] + ' falls between the 0.5 mm grid centres.', field);
        return;
      }
      const index = (Number(value) - coordinate(axis, 0)) * 2;
      if (index < start[axis] || index >= stop[axis]) {
        const range = formatMm(coordinate(axis, start[axis])) + ' to ' +
          formatMm(coordinate(axis, stop[axis] - 1)) + ' mm';
        report(outside + ' ' + axes[axis] + ' runs from ' + range + '.', field);
        return;
      }
      point.push(index);
    }
    report(jump(point));
  };
  form.oninput = event => {
    event.target.removeAttribute('aria-invalid');
    clear();
  };
  function clear() {
    if (status.textContent) status.textContent = '';
  }
  return {
    clear,
    reset() {
      form.reset();
      for (const field of inputs) field.removeAttribute('aria-invalid');
      clear();
    },
  };
}
