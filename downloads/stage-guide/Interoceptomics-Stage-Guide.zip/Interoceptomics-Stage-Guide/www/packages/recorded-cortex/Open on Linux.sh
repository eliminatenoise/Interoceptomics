#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
exec xdg-open docs/recorded-cortex/index.html
