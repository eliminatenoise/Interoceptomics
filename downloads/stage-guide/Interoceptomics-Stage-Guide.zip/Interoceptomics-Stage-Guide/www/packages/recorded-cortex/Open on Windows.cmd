@echo off
start "" "%~dp0docs\recorded-cortex\index.html"
