#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
exec open docs/recorded-cortex/index.html
