The recorded cortex

Extract the whole archive, then open the launcher for your computer. You can also open docs/recorded-cortex/index.html in a browser. The regional comparisons and seven time windows work immediately offline. Choose “Load 3D brain from Stanford” to retrieve one 59 MB source file or choose the original MATLAB file on your own computer. The software reads only the cortical surface, contact positions and region codes from that file. The source-derived signal summaries are supplied separately.

See docs/recorded-cortex/README.md for controls and models/recorded-cortex/METHODS.md for attribution, licensing and the source ethics statement. The anatomy folder contains an optional Python extractor for making a verified packet for offline use. The published study data are licensed under CC BY-SA 4.0. Project code is offered under CC0 to the extent of the project's rights.
